import React, { useState } from 'react';

const PersonCard = (props) => {
    const {firstName, lastName, age, hairColor} = props;

    const [state, setState] = useState({
        age: age
    });

    const increaseAge = () => {
        setState({ age: state.age + 1});
    }        

    return(
        <div>
            <h2>{lastName}, {firstName}</h2>
            <p>Age: {state.age}</p>
            <p>Hair Color: {hairColor}</p>
            <button onClick={increaseAge}>Birthday Button for {firstName} {lastName}</button>
        </div>
    );
}
export default PersonCard;
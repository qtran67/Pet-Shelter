import React, { useState } from 'react'
import axios from 'axios';
const ProductForm = () => {
const [title, setTitle] = useState(""); 
const [price, setPrice] = useState("");
const [desc, setDesc] = useState("");

const onSubmitHandler = (e) => {
    e.preventDefault();

    axios
        .post('http://localhost:8000/api/products', {
        title,
        price,
        desc
    })
        .then(res=>{
            console.log(res);
            console.log(res.data);
        })
        .catch(err=>console.log(err))

        setTitle("");
        setPrice("");
        setDesc("");
    }
    
    return (
        <div>
        <h1>Product Manager</h1>
        <form className='productForm' onSubmit={onSubmitHandler}>
            <div className='form-fields'>
                <label>Title</label><br/>
                <input type="text" value={title} onChange = {(e)=>setTitle(e.target.value)}/>
            </div>
            <div className='form-fields'>
                <label>Price</label><br/>
                <input type="text" value={price} onChange = {(e)=>setPrice(e.target.value)}/>
            </div>
            <div className='form-fields'>
                <label>Description</label><br/>
                <input type="text" value={desc} onChange = {(e)=>setDesc(e.target.value)}/>
            </div>
            <input className="submit-input" type="submit"/>
        </form>
        </div>
    )
}
export default ProductForm;


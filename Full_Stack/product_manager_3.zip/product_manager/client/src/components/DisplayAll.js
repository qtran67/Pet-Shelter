import React, {useEffect, useState} from 'react';
import axios from 'axios';
import {Link} from 'react-router-dom';
import ProductForm from './ProductForm';

const DisplayAll = (props) => {
    const {productList, setProductList} = props;

    useEffect(() =>{
        axios.get("http://localhost:8000/api/products")
        .then((res=>{
            console.log(res);
            console.log(res.data);
            setProductList(res.data);
        }))
        .catch((err)=>console.log(err))
    }, [])

    const deleteProduct = (id) =>{
        axios.delete(`http://localhost:8000/api/products/${id}`)
        .then((res)=>{
            console.log(res.data);
            setProductList(productList.filter((product, index)=>product._id !== id))
        })
        .catch((err)=>console.log(err))
    }

    return(
        <div>
            <h2>All Products:</h2>
            {
                productList.map((product, index)=>(
                    <div className="list-item" key={product._id}>
                        <Link to={`/product/${product._id}`}>{product.title}</Link>
                        <form action={`/product/edit/${product._id}`}>
                            <button style={{margin:3}}>Edit</button>
                        </form>
                        <button style={{margin:3}} onClick={()=>deleteProduct(product._id)}>Delete</button>
                    </div>
                ))
            }
        </div>
    )
}

export default DisplayAll;
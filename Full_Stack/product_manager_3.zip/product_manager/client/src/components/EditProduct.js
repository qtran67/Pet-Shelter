import React, { useState, useEffect } from 'react'
import axios from 'axios';
import { useNavigate, useParams } from 'react-router-dom';

const EditProduct = (props) => {
    const {id} = useParams();
    const [title, setTitle] = useState(""); 
    const [price, setPrice] = useState("");
    const [desc, setDesc] = useState("");

    const navigate = useNavigate();

    useEffect(() => {
        axios.get(`http://localhost:8000/api/products/${id}`)
        .then((res)=>{
            console.log(res);
            console.log(res.data);

            setTitle(res.data.title);
            setPrice(res.data.price);
            setDesc(res.data.desc);
        })
        .catch((err)=>console.log(err));
    },[])

    const onSubmitHandler = (e)=>{
        e. preventDefault();

        axios.put(`http://localhost:8000/api/products/${id}`,{title, price, desc})
        .then((res)=>{
            console.log(res);
            console.log(res.data);
            navigate("/");
        })
        .catch((err)=>console.log(err))
    }
    
    return (
        <div>
            <h1>Edit Product</h1>
            <form className='productForm' onSubmit={onSubmitHandler}>
                <div className='form-fields'>
                    <label>Title</label><br/>
                    <input type="text" value={title} onChange = {(e)=>setTitle(e.target.value)}/>
                </div>
                <div className='form-fields'>
                    <label>Price</label><br/>
                    <input type="text" value={price} onChange = {(e)=>setPrice(e.target.value)}/>
                </div>
                <div className='form-fields'>
                    <label>Description</label><br/>
                    <input type="text" value={desc} onChange = {(e)=>setDesc(e.target.value)}/>
                </div>
                <input className="submit-input" type="submit" value="Update"/>
            </form>
        </div>
    )
}
export default EditProduct;


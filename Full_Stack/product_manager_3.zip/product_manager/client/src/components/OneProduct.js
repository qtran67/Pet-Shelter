import React, {useEffect, useState} from 'react';
import {Link, useNavigate, useParams} from 'react-router-dom';
import axios from 'axios';

const OneProduct = (props) => {
    const {id} = useParams();
    const navigate = useNavigate();

    const [product, setProduct] = useState({})

    useEffect(()=>{
        axios.get(`http://localhost:8000/api/products/${id}`)
        .then((res)=>{
            console.log(res);
            console.log(res.data);
            setProduct(res.data);
        })
        .catch((err)=>console.log(err))
    },[])

    const deleteProduct = () =>{
        axios.delete(`http://localhost:8000/api/products/${id}`)
        .then((res)=>{
            console.log(res.data);
            navigate("/");
        })
        .catch((err)=>console.log(err))
    }

    return(
        <div>
            <h2>{product.title}</h2>
            <p>Price: ${product.price}</p>
            <p>Description: {product.desc}</p>
            <button onClick={deleteProduct}>Delete</button>
            <p></p>
            <Link to={"/"}>Home</Link>
        </div>
    )
}

export default OneProduct;
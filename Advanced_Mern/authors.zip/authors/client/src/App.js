import './App.css';
import React, {useEffect, useState} from 'react';
import {BrowserRouter, Routes, Route} from 'react-router-dom';
import Authors from './components/Authors';
import AuthorForm from './components/AuthorForm';
import EditAuthor from './components/EditAuthor';


function App() {
  const [authorList, setAuthorList] = useState([]);

  return (
    <BrowserRouter>
      <div className="App">
        <h2>Favorite Authors</h2>
        <Routes>
          <Route path="/" element={<Authors/>} />
          <Route path="/new" element={<AuthorForm authorList={authorList} setAuthorList={setAuthorList}/>} />
          <Route path="/edit/:id" element={<EditAuthor/>} />
        </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;

import React, { useState, useEffect } from 'react'
import axios from 'axios';
import { Link, useNavigate, useParams } from 'react-router-dom';

const EditAuthor = (props) => {
    const {id} = useParams();
    const [name, setName] = useState(""); 
    const [errors, setErrors] = useState({});

    const navigate = useNavigate();

    useEffect(() => {
        axios.get(`http://localhost:8000/api/authors/${id}`)
        .then((res)=>{
            console.log(res);
            console.log(res.data);

            setName(res.data.name);
        })
        .catch((err)=>console.log(err));
    },[])

    const onSubmitHandler = (e)=>{
        e. preventDefault();

        axios.put(`http://localhost:8000/api/authors/${id}`,{name})
        .then((res)=>{
            console.log(res);
            console.log(res.data);
            navigate("/");
        })
        .catch((err) => setErrors(err.response.data.error.errors)) 
    }


    return (
        <div>
            <Link to="/">Home</Link>
            <p>Edit this author</p>
            <form className='authorForm' onSubmit={onSubmitHandler}>
                {errors.name && <span style={{color:"red"}}>{errors.name.message}</span>}
                <div className='form-fields'>
                    <label>Name</label><br/>
                    <input type="text" value={name} onChange = {(e)=>setName(e.target.value)}/>
                </div>
                <Link to="/"><button>Cancel</button></Link>
                <input className="submit-input" type="submit" value="Update"/>
            </form>
        </div>
    )
}
export default EditAuthor;


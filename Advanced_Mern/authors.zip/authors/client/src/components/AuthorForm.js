import React, { useState } from 'react'
import axios from 'axios';
import {Link, useNavigate} from 'react-router-dom';

const AuthorForm = (props) => {
    const {authorList, setAuthorList} = props;

    const [name, setName] = useState(""); 
    const [errors, setErrors] = useState({});

    const navigate = useNavigate();

    const onSubmitHandler = (e) => {
        e.preventDefault();

        axios.post('http://localhost:8000/api/authors', {
            name
            })
            .then(res=>{
                console.log(res);
                console.log(res.data);

                setAuthorList([...authorList, res.data])
                navigate("/");
            })
            .catch((err) => setErrors(err.response.data.error.errors))     
    }
    
    return (
        <div>
        <h1>Add Author</h1>
        <Link to="/">Home</Link>
        <p>Add a new author:</p>
        <form className='authorForm' onSubmit={onSubmitHandler}>
        {errors.name && <span style={{color:"red"}}>{errors.name.message}</span>}
            <div className='form-fields'>
                <label>Name</label><br/>
                <input type="text" value={name} onChange = {(e)=>setName(e.target.value)}/>
            </div>
            <input className="submit-input" type="submit"/>
        </form>
        </div>
    )
}

export default AuthorForm;

